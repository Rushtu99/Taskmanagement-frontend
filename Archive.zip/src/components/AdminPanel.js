import React from 'react'

export const AdminPanel = () => {
  return (
    <h1>AdminPanel</h1>
  )
}

