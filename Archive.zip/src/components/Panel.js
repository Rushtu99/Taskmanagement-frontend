import React from 'react'

export const Panel = () => {
  return (
    <h1>Panel</h1>
  )
}

