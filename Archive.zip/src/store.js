import { configureStore } from "@reduxjs/toolkit";


export const mystore = configureStore({
    reducer:{
        
    }
});